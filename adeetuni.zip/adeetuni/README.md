# AdeetUni

Offline speed, location and games app for Android. No internet permission, no ads, no accounts.

## Features
- **Speed**: animated GPS speedometer (km/h, mph, knots), trip timer, max/avg speed, distance, speed-limit vibration alert
- **Place**: live coordinates, altitude, accuracy, heading; copy or share; save named places and see distance and direction to each
- **Compass**: smooth rotating compass using the phone sensor
- **Games**: Reaction Test, Tap Rush, Memory Match, Quick Math (high scores saved)
- **Trips**: history of your last 50 trips with totals

## Build the APK in the cloud
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab, run **Build AdeetUni APK** (it also runs on every push).
3. When it finishes, download the **AdeetUni-debug-apk** artifact, unzip it and install `app-debug.apk` on your phone.

## Notes
- GPS works without internet. Keep the app open on screen while tracking a trip (the screen is kept awake).
- Allow Location permission on first launch and turn Location on in phone settings.
