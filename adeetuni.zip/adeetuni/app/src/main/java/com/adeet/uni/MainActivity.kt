package com.adeet.uni

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), LocationListener, SensorEventListener {

    lateinit var prefs: SharedPreferences
    private lateinit var lm: LocationManager
    private lateinit var sm: SensorManager
    private lateinit var content: FrameLayout
    private val tabViews = ArrayList<TextView>()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var games: Games

    private var refresh: (() -> Unit)? = null
    private var tab = 0

    // live GPS state
    private var last: Location? = null
    private var speedMs = 0f

    // units
    private val units = listOf("km/h", "mph", "kn")
    private val speedFactor = floatArrayOf(3.6f, 2.23694f, 1.94384f)
    private val distUnits = listOf("km", "mi", "nm")
    private val distFactor = doubleArrayOf(0.001, 0.000621371, 0.000539957)
    private val dialScale = floatArrayOf(240f, 150f, 130f)
    private var unitIdx = 0

    // trip state
    private var running = false
    private var tripDist = 0.0
    private var tripStart = 0L
    private var tripMax = 0f
    private var lastCounted: Location? = null

    // speed alert (limit in display units, 0 = off)
    private var limit = 0
    private var lastBuzz = 0L

    // compass
    private var heading = 0f

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        prefs = getSharedPreferences("adeetuni", MODE_PRIVATE)
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        games = Games(this)
        unitIdx = prefs.getInt("unit", 0)
        limit = prefs.getInt("limit", 0)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Theme.BG)
            fitsSystemWindows = true
        }
        content = FrameLayout(this)
        root.addView(content, lp(-1, 0, 1f))

        val bar = LinearLayout(this).apply { setBackgroundColor(Theme.CARD) }
        val names = listOf("🏎️\nSpeed", "📍\nPlace", "🧭\nCompass", "🎮\nGames", "🗺️\nTrips")
        names.forEachIndexed { i, n ->
            val t = tv(n, 12f, Theme.DIM, true, Gravity.CENTER).apply {
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { showTab(i) }
            }
            tabViews.add(t)
            bar.addView(t, lp(0, -2, 1f))
        }
        root.addView(bar, lp(-1, -2))
        setContentView(root)

        showTab(0)
        requestLocationPermission()
        handler.post(object : Runnable {
            override fun run() {
                refresh?.invoke()
                handler.postDelayed(this, 300)
            }
        })
    }

    override fun onResume() {
        super.onResume()
        startGps()
        if (tab == 2) startCompass()
    }

    override fun onPause() {
        super.onPause()
        stopCompass()
        try { lm.removeUpdates(this) } catch (e: SecurityException) {}
    }

    // ----------------------------------------------------------------- GPS

    private fun hasLocationPermission() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestLocationPermission() {
        if (!hasLocationPermission() && Build.VERSION.SDK_INT >= 23) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 1
            )
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        startGps()
    }

    private fun startGps() {
        if (!hasLocationPermission()) return
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
            val known = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (last == null && known != null) last = known
        } catch (e: SecurityException) {
        } catch (e: IllegalArgumentException) {
        }
    }

    override fun onLocationChanged(loc: Location) {
        last = loc
        val s = if (loc.hasSpeed() && loc.speed >= 0.6f) loc.speed else 0f
        speedMs = s
        if (running) {
            if (s > tripMax) tripMax = s
            val lc = lastCounted
            if (lc != null && loc.accuracy < 40f && s > 0f) tripDist += lc.distanceTo(loc)
            if (loc.accuracy < 40f) lastCounted = loc
        }
        val shown = s * speedFactor[unitIdx]
        val now = System.currentTimeMillis()
        if (limit > 0 && shown > limit && now - lastBuzz > 3000) {
            lastBuzz = now
            buzz()
        }
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        v?.vibrate(300)
    }

    @Deprecated("Required on older Android versions")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    private fun gpsStatus(): String = when {
        !hasLocationPermission() -> "Location permission needed"
        !lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> "GPS is OFF — turn on Location"
        last == null -> "Searching for GPS signal…"
        else -> "GPS ±" + last!!.accuracy.toInt() + " m"
    }

    // ----------------------------------------------------------------- tabs

    fun setContent(v: View) {
        content.removeAllViews()
        content.addView(v, FrameLayout.LayoutParams(-1, -1))
    }

    fun showTab(i: Int) {
        tab = i
        games.cancel()
        stopCompass()
        refresh = null
        tabViews.forEachIndexed { n, t -> t.setTextColor(if (n == i) Theme.ACCENT else Theme.DIM) }
        setContent(
            when (i) {
                0 -> buildSpeed()
                1 -> buildPlace()
                2 -> buildCompass()
                3 -> games.menu()
                else -> buildTrips()
            }
        )
    }

    // ---------------------------------------------------------------- speed

    private fun buildSpeed(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val status = tv("", 13f, Theme.DIM, false, Gravity.CENTER)
        col.addView(status, lp(-1, -2))

        val dial = SpeedoView(this)
        col.addView(dial, lp(-1, 0, 1f))

        fun stat(label: String): Pair<LinearLayout, TextView> {
            val v = tv("—", 18f, Theme.TEXT, true, Gravity.CENTER)
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundBg(Theme.CARD)
                setPadding(dp(4), dp(8), dp(4), dp(8))
            }
            box.addView(tv(label, 11f, Theme.DIM, false, Gravity.CENTER))
            box.addView(v)
            return box to v
        }

        val (b1, maxV) = stat("MAX")
        val (b2, avgV) = stat("AVG")
        val (b3, distV) = stat("DIST")
        val (b4, timeV) = stat("TIME")
        val stats = LinearLayout(this)
        listOf(b1, b2, b3, b4).forEach { stats.addView(it, lp(0, -2, 1f).margins(dp(3))) }
        col.addView(stats, lp(-1, -2))

        val unitBtn = btn(units[unitIdx]) {}
        val tripBtn = btn(if (running) "■ Stop trip" else "▶ Start trip") {}
        val limitBtn = btn(if (limit > 0) "Limit $limit" else "Limit off") {}
        unitBtn.setOnClickListener {
            unitIdx = (unitIdx + 1) % units.size
            prefs.edit().putInt("unit", unitIdx).apply()
            limit = 0
            prefs.edit().putInt("limit", 0).apply()
            unitBtn.text = units[unitIdx]
            limitBtn.text = "Limit off"
        }
        tripBtn.setOnClickListener {
            if (!running) {
                running = true
                tripDist = 0.0
                tripMax = 0f
                tripStart = System.currentTimeMillis()
                lastCounted = last
                tripBtn.text = "■ Stop trip"
            } else {
                running = false
                saveTrip()
                tripBtn.text = "▶ Start trip"
                Toast.makeText(this, "Trip saved", Toast.LENGTH_SHORT).show()
            }
        }
        limitBtn.setOnClickListener {
            val steps = if (unitIdx == 0) intArrayOf(0, 40, 60, 80, 100, 120)
            else intArrayOf(0, 25, 40, 55, 70, 80)
            val idx = steps.indexOf(limit)
            limit = steps[(idx + 1) % steps.size]
            prefs.edit().putInt("limit", limit).apply()
            limitBtn.text = if (limit > 0) "Limit $limit" else "Limit off"
        }
        val buttons = LinearLayout(this)
        listOf(unitBtn, tripBtn, limitBtn).forEach { buttons.addView(it, lp(0, -2, 1f).margins(dp(3))) }
        col.addView(buttons, lp(-1, -2))

        refresh = {
            val f = speedFactor[unitIdx]
            dial.maxScale = dialScale[unitIdx]
            dial.unit = units[unitIdx]
            dial.alert = limit > 0 && speedMs * f > limit
            dial.speed = speedMs * f
            status.text = gpsStatus()
            val elapsed = if (running) (System.currentTimeMillis() - tripStart) / 1000 else 0L
            val du = distUnits[unitIdx]
            if (running) {
                maxV.text = String.format(Locale.US, "%.0f", tripMax * f)
                val avg = if (elapsed > 5) (tripDist / elapsed).toFloat() * f else 0f
                avgV.text = String.format(Locale.US, "%.0f", avg)
                distV.text = String.format(Locale.US, "%.2f %s", tripDist * distFactor[unitIdx], du)
                timeV.text = fmtTime(elapsed)
            } else {
                maxV.text = "—"; avgV.text = "—"; distV.text = "—"; timeV.text = "—"
            }
        }
        return col
    }

    private fun saveTrip() {
        val secs = (System.currentTimeMillis() - tripStart) / 1000
        if (secs < 5 && tripDist < 10) return
        val date = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date())
        val avg = if (secs > 0) tripDist / secs else 0.0
        val line = "$date|${tripDist.toLong()}|$secs|$tripMax|$avg"
        val old = prefs.getString("trips", "") ?: ""
        val all = (listOf(line) + old.split("\n").filter { it.isNotBlank() }).take(50)
        prefs.edit().putString("trips", all.joinToString("\n")).apply()
    }

    // ---------------------------------------------------------------- place

    private fun coordText(l: Location) =
        String.format(Locale.US, "%.6f, %.6f", l.latitude, l.longitude)

    private fun buildPlace(): View {
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        scroll.addView(col)
        col.addView(tv("My location", 26f, Theme.ACCENT, true))
        val status = tv("", 13f, Theme.DIM)
        col.addView(status)

        val info = tv("", 17f, Theme.TEXT)
        info.setLineSpacing(0f, 1.25f)
        col.addView(card(info), lp(-1, -2).margins(dp(4)))

        val actions = LinearLayout(this)
        actions.addView(btn("Copy") {
            last?.let {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("coords", coordText(it)))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            } ?: Toast.makeText(this, "No GPS fix yet", Toast.LENGTH_SHORT).show()
        }, lp(0, -2, 1f).margins(dp(3)))
        actions.addView(btn("Share") {
            last?.let {
                val txt = "My location: ${coordText(it)}\nhttps://maps.google.com/?q=${coordText(it).replace(" ", "")}"
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, txt)
                }
                startActivity(Intent.createChooser(send, "Share location"))
            } ?: Toast.makeText(this, "No GPS fix yet", Toast.LENGTH_SHORT).show()
        }, lp(0, -2, 1f).margins(dp(3)))
        col.addView(actions)

        col.addView(tv("Saved places", 20f, Theme.TEXT, true).apply { setPadding(0, dp(14), 0, dp(4)) })
        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val placeViews = ArrayList<Pair<TextView, DoubleArray>>()

        fun loadPlaces(): List<Triple<String, Double, Double>> =
            (prefs.getString("places", "") ?: "").split("\n").mapNotNull {
                val p = it.split("|")
                if (p.size == 3) {
                    val la = p[1].toDoubleOrNull()
                    val lo = p[2].toDoubleOrNull()
                    if (la != null && lo != null) Triple(p[0], la, lo) else null
                } else null
            }

        fun rebuildList() {
            listBox.removeAllViews()
            placeViews.clear()
            val places = loadPlaces()
            if (places.isEmpty()) listBox.addView(tv("Nothing saved yet.", 14f, Theme.DIM))
            places.forEachIndexed { idx, (name, la, lo) ->
                val t = tv(name, 15f, Theme.TEXT)
                val c = card(t)
                c.setOnLongClickListener {
                    AlertDialog.Builder(this)
                        .setTitle("Delete \"$name\"?")
                        .setPositiveButton("Delete") { _, _ ->
                            val rest = loadPlaces().filterIndexed { i, _ -> i != idx }
                            prefs.edit().putString("places", rest.joinToString("\n") { "${it.first}|${it.second}|${it.third}" }).apply()
                            rebuildList()
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                    true
                }
                listBox.addView(c, lp(-1, -2).margins(dp(4)))
                placeViews.add(t to doubleArrayOf(la, lo))
                t.tag = name
            }
        }

        col.addView(btn("＋ Save this place") {
            val here = last
            if (here == null) {
                Toast.makeText(this, "No GPS fix yet", Toast.LENGTH_SHORT).show()
            } else {
                val input = EditText(this).apply {
                    hint = "Name (Home, Camp, Parking…)"
                    inputType = InputType.TYPE_CLASS_TEXT
                }
                AlertDialog.Builder(this)
                    .setTitle("Save place")
                    .setView(input)
                    .setPositiveButton("Save") { _, _ ->
                        val nm = input.text.toString().replace("|", " ").replace("\n", " ").trim().ifEmpty { "Place" }
                        val old = prefs.getString("places", "") ?: ""
                        val line = "$nm|${here.latitude}|${here.longitude}"
                        prefs.edit().putString("places", if (old.isBlank()) line else "$old\n$line").apply()
                        rebuildList()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }, lp(-1, -2).margins(dp(3)))
        col.addView(listBox)
        col.addView(tv("Long-press a saved place to delete it.", 12f, Theme.DIM).apply { setPadding(0, dp(6), 0, 0) })
        rebuildList()

        refresh = {
            status.text = gpsStatus()
            val l = last
            info.text = if (l == null) "Waiting for GPS…" else buildString {
                append("Lat / Lon\n").append(coordText(l)).append("\n")
                append("Altitude: ").append(if (l.hasAltitude()) "${l.altitude.toInt()} m" else "—").append("\n")
                append("Accuracy: ±").append(l.accuracy.toInt()).append(" m\n")
                append("Heading: ").append(if (l.hasBearing()) "${l.bearing.toInt()}° ${cardinal(l.bearing)}" else "—")
            }
            val here = last
            for ((t, ll) in placeViews) {
                val name = t.tag as String
                t.text = if (here == null) name else {
                    val res = FloatArray(2)
                    Location.distanceBetween(here.latitude, here.longitude, ll[0], ll[1], res)
                    val d = res[0]
                    val dTxt = if (d < 1000) "${d.toInt()} m" else String.format(Locale.US, "%.2f km", d / 1000)
                    val brg = (res[1] + 360f) % 360f
                    "$name\n$dTxt away · ${brg.toInt()}° ${cardinal(brg)}"
                }
            }
        }
        return scroll
    }

    private fun cardinal(deg: Float): String {
        val names = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
        return names[(((deg % 360f) + 360f) % 360f / 45f + 0.5f).toInt() % 8]
    }

    // -------------------------------------------------------------- compass

    private var compassOn = false

    private fun startCompass() {
        val s = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) ?: return
        if (!compassOn) {
            sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI)
            compassOn = true
        }
    }

    private fun stopCompass() {
        if (compassOn) {
            sm.unregisterListener(this)
            compassOn = false
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
        val r = FloatArray(9)
        val o = FloatArray(3)
        SensorManager.getRotationMatrixFromVector(r, e.values)
        SensorManager.getOrientation(r, o)
        val az = ((Math.toDegrees(o[0].toDouble()) + 360.0) % 360.0).toFloat()
        // smooth, handling the 359 -> 0 wrap
        var diff = az - heading
        if (diff > 180f) diff -= 360f
        if (diff < -180f) diff += 360f
        heading = (heading + diff * 0.25f + 360f) % 360f
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun buildCompass(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        col.addView(tv("Compass", 26f, Theme.ACCENT, true))
        val view = CompassView(this)
        col.addView(view, lp(-1, 0, 1f))
        val deg = tv("", 40f, Theme.TEXT, true, Gravity.CENTER)
        col.addView(deg)
        val note = tv("", 13f, Theme.DIM, false, Gravity.CENTER)
        col.addView(note)
        if (sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) == null) {
            note.text = "This phone has no compass sensor."
        } else {
            note.text = "Hold the phone flat. Wave it in a figure-8 if it seems off."
            startCompass()
        }
        refresh = {
            view.heading = heading
            deg.text = "${heading.toInt()}° ${cardinal(heading)}"
        }
        return col
    }

    // ---------------------------------------------------------------- trips

    private fun buildTrips(): View {
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        scroll.addView(col)
        col.addView(tv("Trips", 26f, Theme.ACCENT, true))
        val f = speedFactor[unitIdx]
        val trips = (prefs.getString("trips", "") ?: "").split("\n").filter { it.isNotBlank() }
        if (trips.isEmpty()) {
            col.addView(tv("No trips yet. Press ▶ Start trip on the Speed tab.", 14f, Theme.DIM))
        }
        var total = 0.0
        for (line in trips) {
            val p = line.split("|")
            if (p.size < 5) continue
            val dist = p[1].toDoubleOrNull() ?: 0.0
            val secs = p[2].toLongOrNull() ?: 0L
            val mx = (p[3].toFloatOrNull() ?: 0f) * f
            val av = (p[4].toDoubleOrNull() ?: 0.0).toFloat() * f
            total += dist
            col.addView(
                card(
                    tv(p[0], 14f, Theme.DIM),
                    tv(
                        String.format(Locale.US, "%.2f %s · %s", dist * distFactor[unitIdx], distUnits[unitIdx], fmtTime(secs)),
                        18f, Theme.TEXT, true
                    ),
                    tv(String.format(Locale.US, "Max %.0f · Avg %.0f %s", mx, av, units[unitIdx]), 14f, Theme.GOOD)
                ),
                lp(-1, -2).margins(dp(4))
            )
        }
        if (trips.isNotEmpty()) {
            col.addView(
                tv(
                    String.format(Locale.US, "Total: %.2f %s", total * distFactor[unitIdx], distUnits[unitIdx]),
                    16f, Theme.ACCENT, true
                ).apply { setPadding(0, dp(10), 0, dp(6)) }
            )
            col.addView(btn("Clear all trips", Theme.BAD) {
                AlertDialog.Builder(this)
                    .setTitle("Clear all trips?")
                    .setPositiveButton("Clear") { _, _ ->
                        prefs.edit().remove("trips").apply()
                        showTab(4)
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            })
        }
        return scroll
    }
}
