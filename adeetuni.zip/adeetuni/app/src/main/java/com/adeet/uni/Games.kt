package com.adeet.uni

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.random.Random

/** Four small offline games. High scores are stored in SharedPreferences. */
class Games(private val act: MainActivity) {

    private val h = Handler(Looper.getMainLooper())

    fun cancel() = h.removeCallbacksAndMessages(null)

    private fun best(key: String, def: Int) = act.prefs.getInt(key, def)
    private fun setBest(key: String, v: Int) = act.prefs.edit().putInt(key, v).apply()

    private fun backButton(): Button = act.btn("‹ Back") {
        cancel()
        act.showTab(3)
    }.apply {
        layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(act.dp(12), act.dp(12), 0, 0) }
    }

    // ---------------------------------------------------------------- menu

    fun menu(): View {
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(act.dp(16), act.dp(16), act.dp(16), act.dp(16))
        }
        col.addView(act.tv("Games", 26f, Theme.ACCENT, true))
        col.addView(act.tv("All games work offline.", 13f, Theme.DIM))

        fun entry(title: String, sub: String, score: String, open: () -> View) {
            val c = act.card(
                act.tv(title, 18f, Theme.TEXT, true),
                act.tv(sub, 13f, Theme.DIM),
                act.tv(score, 13f, Theme.GOOD)
            )
            c.setOnClickListener { act.setContent(open()) }
            col.addView(c, lp(-1, -2).margins(act.dp(6)))
        }

        val r = best("best_reaction", Int.MAX_VALUE)
        entry("⚡ Reaction Test", "Tap the moment the screen turns green.",
            if (r == Int.MAX_VALUE) "Best: —" else "Best: $r ms") { reaction() }
        entry("👆 Tap Rush", "Tap as many times as you can in 10 seconds.",
            "Best: ${best("best_tap", 0)} taps") { tapRush() }
        entry("🧠 Memory Match", "Find all 8 pairs in the fewest moves.",
            best("best_mem", 0).let { if (it == 0) "Best: —" else "Best: $it moves" }) { memory() }
        entry("➗ Quick Math", "10 questions. Answer fast and right.",
            "Best: ${best("best_math", 0)} / 10") { math() }
        return col
    }

    // ------------------------------------------------------------ reaction

    private fun reaction(): View {
        val root = FrameLayout(act)
        root.setBackgroundColor(0xFF1565C0.toInt())
        val msg = act.tv("Tap to start", 28f, 0xFFFFFFFF.toInt(), true, Gravity.CENTER)
        root.addView(msg, FrameLayout.LayoutParams(-1, -1))
        root.addView(backButton())

        var state = 0 // 0 idle, 1 waiting, 2 go, 3 result
        var t0 = 0L
        val goRunnable = Runnable {
            state = 2
            t0 = SystemClock.elapsedRealtime()
            root.setBackgroundColor(Theme.GOOD)
            msg.text = "TAP!"
            msg.setTextColor(0xFF000000.toInt())
        }
        root.setOnClickListener {
            when (state) {
                0, 3 -> {
                    state = 1
                    root.setBackgroundColor(0xFFC62828.toInt())
                    msg.setTextColor(0xFFFFFFFF.toInt())
                    msg.text = "Wait for green…"
                    h.postDelayed(goRunnable, 1000L + Random.nextInt(3000))
                }
                1 -> {
                    h.removeCallbacks(goRunnable)
                    state = 3
                    root.setBackgroundColor(0xFF1565C0.toInt())
                    msg.text = "Too soon!\nTap to try again"
                }
                2 -> {
                    val ms = (SystemClock.elapsedRealtime() - t0).toInt()
                    state = 3
                    root.setBackgroundColor(0xFF1565C0.toInt())
                    msg.setTextColor(0xFFFFFFFF.toInt())
                    val old = best("best_reaction", Int.MAX_VALUE)
                    if (ms < old) setBest("best_reaction", ms)
                    val b = minOf(ms, old)
                    msg.text = "$ms ms\nBest: $b ms\n\nTap to try again"
                }
            }
        }
        return root
    }

    // ------------------------------------------------------------ tap rush

    private fun tapRush(): View {
        val root = FrameLayout(act)
        root.setBackgroundColor(Theme.BG)
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val timer = act.tv("10.0", 30f, Theme.WARN, true, Gravity.CENTER)
        val count = act.tv("0", 80f, Theme.ACCENT, true, Gravity.CENTER)
        val hint = act.tv("Tap the button to start", 14f, Theme.DIM, false, Gravity.CENTER)
        var taps = 0
        var running = false
        var over = false
        var endAt = 0L

        lateinit var big: Button
        val tick = object : Runnable {
            override fun run() {
                val left = endAt - SystemClock.elapsedRealtime()
                if (left <= 0) {
                    running = false
                    over = true
                    timer.text = "0.0"
                    val b = best("best_tap", 0)
                    if (taps > b) setBest("best_tap", taps)
                    hint.text = "Time! $taps taps. Best: ${maxOf(b, taps)}\nTap to play again"
                    big.text = "AGAIN"
                    return
                }
                timer.text = String.format(java.util.Locale.US, "%.1f", left / 1000.0)
                h.postDelayed(this, 50)
            }
        }
        big = act.btn("TAP!", Theme.ACCENT) {
            if (over) {
                over = false
                taps = 0
                count.text = "0"
                timer.text = "10.0"
                hint.text = "Tap the button to start"
                big.text = "TAP!"
            } else {
                if (!running) {
                    running = true
                    endAt = SystemClock.elapsedRealtime() + 10_000
                    hint.text = "Go go go!"
                    h.post(tick)
                }
                taps++
                count.text = taps.toString()
            }
        }.apply {
            setTextColor(0xFF000000.toInt())
            textSize = 28f
        }
        col.addView(timer)
        col.addView(count)
        col.addView(hint)
        col.addView(big, lp(act.dp(240), act.dp(240)).margins(act.dp(24)))
        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        root.addView(backButton())
        return root
    }

    // -------------------------------------------------------------- memory

    private fun memory(): View {
        val symbols = listOf("🚗", "🏍️", "🚲", "✈️", "🚀", "⛵", "🚂", "🛵")
        val deck = (symbols + symbols).shuffled()
        val root = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(act.dp(12), act.dp(12), act.dp(12), act.dp(12))
        }
        val top = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(backButton().apply { layoutParams = lp(-2, -2) })
        val info = act.tv("Moves: 0", 18f, Theme.ACCENT, true, Gravity.END)
        top.addView(info, lp(0, -2, 1f))
        root.addView(top)

        val cards = ArrayList<Button>()
        val matched = BooleanArray(16)
        var first = -1
        var lock = false
        var moves = 0
        var pairs = 0

        val grid = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        for (row in 0 until 4) {
            val line = LinearLayout(act)
            for (colIdx in 0 until 4) {
                val i = row * 4 + colIdx
                val b = act.btn("?", Theme.CARD) {}.apply { textSize = 28f }
                b.setOnClickListener {
                    if (lock || matched[i] || i == first) return@setOnClickListener
                    b.text = deck[i]
                    if (first == -1) {
                        first = i
                    } else {
                        moves++
                        info.text = "Moves: $moves"
                        val a = first
                        first = -1
                        if (deck[a] == deck[i]) {
                            matched[a] = true
                            matched[i] = true
                            cards[a].background = act.roundBg(0xFF1B5E20.toInt())
                            b.background = act.roundBg(0xFF1B5E20.toInt())
                            pairs++
                            if (pairs == 8) {
                                val old = best("best_mem", 0)
                                if (old == 0 || moves < old) setBest("best_mem", moves)
                                info.text = "Done in $moves moves! 🎉"
                            }
                        } else {
                            lock = true
                            h.postDelayed({
                                cards[a].text = "?"
                                b.text = "?"
                                lock = false
                            }, 700)
                        }
                    }
                }
                cards.add(b)
                line.addView(b, lp(0, act.dp(84), 1f).margins(act.dp(4)))
            }
            grid.addView(line)
        }
        root.addView(grid, lp(-1, -2).margins(act.dp(4)))
        return root
    }

    // ---------------------------------------------------------------- math

    private fun math(): View {
        val root = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(act.dp(16), act.dp(12), act.dp(16), act.dp(12))
        }
        val top = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(backButton().apply { layoutParams = lp(-2, -2) })
        val progress = act.tv("Q 1/10", 16f, Theme.DIM, false, Gravity.END)
        top.addView(progress, lp(0, -2, 1f))
        root.addView(top)

        val question = act.tv("", 44f, Theme.TEXT, true, Gravity.CENTER)
        root.addView(question, lp(-1, 0, 1f))
        val answers = ArrayList<Button>()
        val rows = listOf(LinearLayout(act), LinearLayout(act))
        for (n in 0 until 4) {
            val b = act.btn("", Theme.CARD) {}.apply { textSize = 22f }
            answers.add(b)
            rows[n / 2].addView(b, lp(0, act.dp(80), 1f).margins(act.dp(5)))
        }
        rows.forEach { root.addView(it) }

        var q = 0
        var score = 0
        var correct = 0
        val startedAt = SystemClock.elapsedRealtime()

        fun next() {
            if (q == 10) {
                val secs = (SystemClock.elapsedRealtime() - startedAt) / 1000
                if (score > best("best_math", 0)) setBest("best_math", score)
                question.text = "$score / 10"
                progress.text = "Time ${secs}s"
                answers.forEach { it.visibility = View.GONE }
                return
            }
            q++
            progress.text = "Q $q/10"
            val a = Random.nextInt(2, 13)
            val b = Random.nextInt(2, 13)
            val (text, ans) = when (Random.nextInt(3)) {
                0 -> "$a + $b" to a + b
                1 -> "${a + b} − $b" to a
                else -> "$a × $b" to a * b
            }
            question.text = text
            correct = Random.nextInt(4)
            val used = HashSet<Int>()
            used.add(ans)
            for (n in 0 until 4) {
                val v = if (n == correct) ans else {
                    var w: Int
                    do { w = ans + Random.nextInt(-9, 10) } while (w < 0 || !used.add(w))
                    w
                }
                answers[n].text = v.toString()
                answers[n].setOnClickListener {
                    if (n == correct) score++
                    next()
                }
            }
        }
        next()
        return root
    }
}
