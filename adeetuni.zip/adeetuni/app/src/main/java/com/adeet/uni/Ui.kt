package com.adeet.uni

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

object Theme {
    const val BG = 0xFF0B1020.toInt()
    const val CARD = 0xFF151D36.toInt()
    const val ACCENT = 0xFF00E5FF.toInt()
    const val TEXT = 0xFFEAF2FF.toInt()
    const val DIM = 0xFF8FA0C0.toInt()
    const val GOOD = 0xFF69F0AE.toInt()
    const val WARN = 0xFFFFC107.toInt()
    const val BAD = 0xFFFF5252.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.tv(
    text: String,
    size: Float = 16f,
    color: Int = Theme.TEXT,
    bold: Boolean = false,
    gravity: Int = Gravity.START
): TextView = TextView(this).apply {
    this.text = text
    textSize = size
    setTextColor(color)
    this.gravity = gravity
    if (bold) setTypeface(typeface, Typeface.BOLD)
}

fun Context.roundBg(color: Int, radiusDp: Int = 14): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

fun Context.btn(text: String, color: Int = Theme.CARD, onClick: () -> Unit): Button =
    Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Theme.TEXT)
        textSize = 14f
        background = roundBg(color)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        setOnClickListener { onClick() }
    }

fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(w, h, weight)

fun LinearLayout.LayoutParams.margins(px: Int): LinearLayout.LayoutParams {
    setMargins(px, px, px, px)
    return this
}

fun Context.card(vararg views: View): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = roundBg(Theme.CARD)
    setPadding(dp(14), dp(12), dp(14), dp(12))
    views.forEach { addView(it) }
}

fun fmtTime(sec: Long): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, s)
}

@Suppress("unused")
val TRANSPARENT = Color.TRANSPARENT
