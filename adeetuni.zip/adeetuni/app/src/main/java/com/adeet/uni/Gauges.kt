package com.adeet.uni

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Animated speedometer dial. Fully drawn on a Canvas, no assets needed. */
class SpeedoView(ctx: Context) : View(ctx) {
    var speed = 0f
        set(v) { field = v; postInvalidateOnAnimation() }
    var maxScale = 240f
    var unit = "km/h"
    var alert = false
    private var shown = 0f

    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Theme.DIM
        strokeWidth = 4f
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Theme.DIM
        textAlign = Paint.Align.CENTER
    }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Theme.TEXT
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val needle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Theme.BAD
        style = Paint.Style.FILL
    }
    private val hub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Theme.TEXT }

    override fun onDraw(c: Canvas) {
        shown += (speed - shown) * 0.18f
        if (abs(speed - shown) < 0.05f) shown = speed

        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f * 0.86f
        arc.strokeWidth = r * 0.10f

        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        arc.color = 0xFF1E2A44.toInt()
        c.drawArc(rect, 135f, 270f, false, arc)

        val frac = (shown / maxScale).coerceIn(0f, 1f)
        arc.color = when {
            alert -> Theme.BAD
            frac < 0.5f -> Theme.GOOD
            frac < 0.8f -> Theme.WARN
            else -> Theme.BAD
        }
        if (frac > 0f) c.drawArc(rect, 135f, 270f * frac, false, arc)

        label.textSize = r * 0.09f
        for (i in 0..10) {
            val a = Math.toRadians(135.0 + 27.0 * i)
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            c.drawLine(cx + ca * r * 0.80f, cy + sa * r * 0.80f, cx + ca * r * 0.88f, cy + sa * r * 0.88f, tick)
            val v = (maxScale * i / 10f).toInt()
            c.drawText(v.toString(), cx + ca * r * 0.67f, cy + sa * r * 0.67f + label.textSize / 3f, label)
        }

        // needle
        val na = Math.toRadians(135.0 + 270.0 * frac)
        val nx = cos(na).toFloat()
        val ny = sin(na).toFloat()
        val px = -ny
        val py = nx
        val path = Path().apply {
            moveTo(cx + nx * r * 0.72f, cy + ny * r * 0.72f)
            lineTo(cx + px * r * 0.04f, cy + py * r * 0.04f)
            lineTo(cx - px * r * 0.04f, cy - py * r * 0.04f)
            close()
        }
        c.drawPath(path, needle)
        c.drawCircle(cx, cy, r * 0.06f, hub)

        big.textSize = r * 0.42f
        c.drawText(shown.toInt().toString(), cx, cy + r * 0.62f, big)
        label.textSize = r * 0.12f
        c.drawText(unit, cx, cy + r * 0.80f, label)

        if (shown != speed) postInvalidateOnAnimation()
    }
}

/** Rotating compass dial. heading = degrees clockwise from north. */
class CompassView(ctx: Context) : View(ctx) {
    var heading = 0f
        set(v) { field = v; invalidate() }

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFF1E2A44.toInt()
    }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Theme.DIM
        strokeWidth = 3f
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Theme.TEXT
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val ptr = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Theme.BAD
        style = Paint.Style.FILL
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.86f
        ring.strokeWidth = r * 0.06f

        c.save()
        c.rotate(-heading, cx, cy)
        c.drawCircle(cx, cy, r, ring)
        for (i in 0 until 72) {
            val len = if (i % 9 == 0) r * 0.12f else r * 0.05f
            c.save()
            c.rotate(i * 5f, cx, cy)
            c.drawLine(cx, cy - r, cx, cy - r + len, tick)
            c.restore()
        }
        txt.textSize = r * 0.18f
        val names = listOf(0 to "N", 90 to "E", 180 to "S", 270 to "W")
        for ((deg, name) in names) {
            c.save()
            c.rotate(deg.toFloat(), cx, cy)
            txt.color = if (deg == 0) Theme.BAD else Theme.TEXT
            c.drawText(name, cx, cy - r * 0.70f, txt)
            c.restore()
        }
        c.restore()

        val p = Path().apply {
            moveTo(cx, cy - r * 1.08f)
            lineTo(cx - r * 0.05f, cy - r * 0.92f)
            lineTo(cx + r * 0.05f, cy - r * 0.92f)
            close()
        }
        c.drawPath(p, ptr)
    }
}
